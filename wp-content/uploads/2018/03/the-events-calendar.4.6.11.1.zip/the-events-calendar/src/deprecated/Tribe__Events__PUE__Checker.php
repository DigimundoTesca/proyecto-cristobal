<?php
_deprecated_file( __FILE__, '4.2', 'Tribe__PUE__Checker' );


class Tribe__Events__PUE__Checker extends Tribe__PUE__Checker {

}