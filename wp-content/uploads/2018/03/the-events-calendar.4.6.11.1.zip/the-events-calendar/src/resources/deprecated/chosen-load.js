jQuery(document).ready(function() {
	jQuery('.chosen').chosen();
});