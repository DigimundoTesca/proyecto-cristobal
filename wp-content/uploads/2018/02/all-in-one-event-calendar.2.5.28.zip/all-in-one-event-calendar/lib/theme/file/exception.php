<?php
/**
 * Exception thrown when a file/extension is not found.
 *
 * @author     Time.ly Network Inc.
 * @since      2.0
 *
 * @package    AI1EC
 * @subpackage AI1EC.Theme.File
 */
class Ai1ec_File_Exception extends Ai1ec_Exception {

}