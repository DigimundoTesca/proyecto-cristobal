<div id="message" class="ai1ec-alert ai1ec-alert-danger">
  <strong>
    <?php echo esc_html( _X( $message, 'calendar-feeds', AI1EC_PLUGIN_NAME ) )?>
  </strong>
</div>

